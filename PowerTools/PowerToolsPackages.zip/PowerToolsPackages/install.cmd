@echo off
rem Install the Windows Phone Power Tools packages by hand.
rem Run from the folder that contains reg\, bin\ and cat\.
setlocal
set CAT=C:\Windows\System32\catroot\{F750E6C3-38EE-11D1-85E5-00C04FC295EE}
echo === Binaries
for %%F in (bin\*) do copy /y "%%F" C:\Windows\System32\ || goto :fail
echo === Catalogs
for %%F in (cat\*.cat) do copy /y "%%F" "%CAT%\" || goto :fail
echo === Registry
for %%F in (reg\*.reg) do reg import "%%F" || goto :fail
echo === Check
reg query "HKLM\SOFTWARE\Microsoft\Windows Phone\Power Tools\Packages" /s /v Version
echo Done. Reboot the phone so that the new catalogs are taken into account.
goto :eof
:fail
echo FAILED (error %errorlevel%)
exit /b 1
